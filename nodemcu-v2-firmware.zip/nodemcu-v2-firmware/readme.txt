0. Browse to the Python Installation Folder - C:\Users\Username\AppData\Local\Programs\Python
-----------------------------------------------------------------------------------------------------
1. Install the The latest stable version of esptool 

pip install esptool
-----------------------------------------------------------------------------------------------------
2. To gather the board’s info, run the flash_id command.

esptool.py flash_id
-----------------------------------------------------------------------------------------------------
3. Save 4MByte or 32Mbit Flash

esptool.py --baud 115200 --port COM8 read_flash 0x0 0x400000 fw-backup-4M.bin
-----------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------
Restore 4MByte or 32Mbit Flash

esptool.py --baud 115200 --port COM8 write_flash 0x0 fw-backup-4M.bin
-----------------------------------------------------------------------------------------------------







esptool.py --baud 115200 --port COM8 read_flash 0x0 0x400000 fw-backup-4M.bin
–baud 115200, the baud rate of the data transfer
–port COM8, the communications port where the board is connected
read_flash, the specific command
0x0, the starting address of the flash memory to read in hexadecimal
0x100000, the size of flash memory to read in hexadecimal (1048576 or 1MB decimal)
fw-backup-1M.bin, file name of the saved firmware
